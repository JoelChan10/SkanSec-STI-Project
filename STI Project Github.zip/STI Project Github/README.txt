###########################################################################################################################################################################################


SKANSEC AI CHATBOT SETUP

Setting up anaconda environment

1) Install anaconda prompt from https://www.anaconda.com/products/individual

2) In this Chatbot project, we are using python 3.6. So go ahead and type 
	# conda create -n skanbot python=3.6
   in the anaconda prompt, replacing 'skanbot' with the environment name of your choice.

3) Type 
	# activate skanbot 
   to activate the environment

4) We will need to install a bunch of packages in this environment. Perform the following commands while still in your environment:
	# conda install tensorflow=1.14
	# conda install django (Django is used to implement the Chatbot into a web application)
	# conda install nltk
	# conda install numpy


Django framework and configurations

5) After you have downloaded and unzipped our Chatbot folder, find settings.py file inside /Tensorflow_Chatbot directory and replace line 96 according to the path of the static folder of
your project (under STATICFILES_DIRS variable).


Chatbot training and data model

6) View the content.json file with a code editor of your choice under /Bot directory. This will be the data that the bot will learn and can be fully customizable to suit your needs.

7) Execute train.py file under /Bot directory to train the data model:
	# python train.py

8) Navigate back to the root directory of the foler (/Tensorflow-Chatbot-master folder) and execute the following command to start the webserver.
	# python manage.py runserver


###########################################################################################################################################################################################


URL BLOCKER EXTENSION SETUP

1) Downloadd the extension from https://1drv.ms/u/s!AlXkVbSpa3x02iwZJcN-Ts4yfpZQ?e=1TAet3

2) To launch the google extensions, head to more tools and there will be an extensions folder 

3) Simply click the load unpacked to launch the extension

4) Choose the downnloaded file and it will run in the background. 


###########################################################################################################################################################################################


SKANSEC PASSWORD STRENGTH TESTER SETUP

1) Put the index.html and and pw-strength-tester.js files inside htdocs of XAMPP/ any local webserver

2) Launch the Password Strength Tester through any web browser and you are good to go.


###########################################################################################################################################################################################


SKANSEC SOCIAL MEDIA DETECTOR SET UP

1. Put the index.html and and demo.js files inside htdocs of XAMPP/ any local webserver

2. Launch the index.html through any web browser.


###########################################################################################################################################################################################


SKANSEC CYBERSECURITY AWARENESS SET UP

1. Put the phishing.html, malvertising.html and images inside htdocs of XAMPP/ any local webserver

2. Launch the phishing.html and malvertising.html through any web browser.


###########################################################################################################################################################################################


SKANSEC ANTIVIRUS SET UP

1. Download the SkanSec Antivirus folder

2. Open the Tutorial.sln through the folder in the Visual Studio

3. In the Visual Studio, got to tab project and click Tutorial Properties

4. Go to tab publish and choose a directory you would like to publish it in.


###########################################################################################################################################################################################