document.getElementById("WebsiteLinkButton").addEventListener("click", function() {
    chrome.tabs.update({url: "http://localhost/skansec/index.php"});

  
});


document.getElementById("addLinkButton").addEventListener("click", function() {
    chrome.tabs.update({url: "/database.html"});

  
});