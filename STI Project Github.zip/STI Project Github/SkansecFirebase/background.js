



var firebaseConfig = {
  apiKey: "AIzaSyBVSJQj8CrsB1lIVjUJl_sphLyWzBJv4tw",
  authDomain: "skansec-7fbac.firebaseapp.com",
  databaseURL: "https://skansec-7fbac.firebaseio.com",
  projectId: "skansec-7fbac",
  storageBucket: "skansec-7fbac.appspot.com",
  messagingSenderId: "161060484691",
  appId: "1:161060484691:web:79eca38e167d8c1e6278a6",
  measurementId: "G-Y3NKHWQZ9G"
};

firebase.initializeApp(firebaseConfig);




var db = firebase.firestore();
var docRef = db.collection('urls');
var insertdata = db.collection('urls').doc();


// // add
// document.getElementById('save').addEventListener('click', function insertData() {

//   var url = document.getElementById('url').value;

//   db.collection("urls").doc().set({
//     urls: url
//   })
//     .then(function () {
//       alert("url successfully added!");
//       location.reload();
//     })
//     .catch(function (error) {
//       alert("Error writing document: ", error);
//     });


// });



// // delete
// document.getElementById('delete').addEventListener('click', function insertData() {

//   var url = document.getElementById('url').value;
//   db.collection("urls").where("urls", "==", url)
//   .get()
//   .then((querySnapshot) => {
//     querySnapshot.forEach(doc=>{
//       doc.ref.delete()
//     })
//   });

// });




// this is to get urls from database an push it to an array and block the websites


docRef
  .get()
  .then(function (querySnapshot) {
    var arrayOfUrls = [];
    var arrayshow = [];
    querySnapshot.forEach(doc => {
      arrayOfUrls.push(doc.data().urls);
      arrayshow.push(doc.data().urls);

    });
    console.log(arrayOfUrls);

    chrome.webRequest.onBeforeRequest.addListener(
      function (details) { return { cancel: true }; },
      { urls: arrayOfUrls },
      ["blocking"]
    );
    
// document.getElementById("display").innerHTML = arrayshow;
// document.getElementById("display").innerHTML += (i+1) + ": " + arrayshow[i];

arrayshow.forEach(v => {
  document.getElementById("display").innerHTML += v + '\n';
});


});



